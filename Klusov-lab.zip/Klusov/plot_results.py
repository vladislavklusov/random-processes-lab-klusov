import csv
import matplotlib.pyplot as plt


def read_table(name):
    with open("results/" + name, encoding="utf-8") as file:
        return list(csv.DictReader(file))


rows = read_table("summary.csv")
numbers = [int(r["file"][-6:-4]) for r in rows]
fig, axes = plt.subplots(2, 2, figsize=(10, 7), constrained_layout=True)
for ax, (key, label) in zip(axes.flat, [
    ("spikes", "Число спайков"), ("mean_isi", "Средний ISI"),
    ("amplitude", "Максимальная амплитуда"), ("cv", "Коэффициент вариации ISI")
]):
    ax.plot(numbers, [float(r[key]) for r in rows], ".-")
    ax.set(xlabel="Номер файла", ylabel=label)
    ax.grid(alpha=0.25)
fig.savefig("results/by_file.png", dpi=150)

fig, axes = plt.subplots(3, 1, figsize=(9, 8), constrained_layout=True)
prefix = "TSi0a1-05_"
for ax, (name, x, y, limit, xlabel, ylabel) in zip(axes, [
    ("spectrum", "frequency", "amplitude", 1, "Частота, 1/ед. времени", "Амплитуда"),
    ("acf", "lag", "acf", 12, "Сдвиг, ед. времени", "АКФ"),
    ("isi", "index", "isi", 100000, "Номер интервала", "ISI, ед. времени")
]):
    points = [r for r in read_table(prefix + name + ".csv") if float(r[x]) <= limit]
    ax.plot([float(r[x]) for r in points], [float(r[y]) for r in points], linewidth=1)
    ax.set(xlabel=xlabel, ylabel=ylabel)
    ax.grid(alpha=0.25)
axes[1].axhline(0.367879, color="gray", linestyle="--", label="1/e")
axes[1].legend()
fig.savefig("results/example.png", dpi=150)
