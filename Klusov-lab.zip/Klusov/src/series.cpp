#include "series.h"
#include <cmath>
#include <fstream>
#include <sstream>
#include <stdexcept>

Series read_series(const std::string& path) {
    std::ifstream file(path);
    if (!file) throw std::runtime_error("Не удалось открыть файл");

    Series s{};
    std::string line;
    int row = 0;
    while (std::getline(file, line)) {
        ++row;
        std::istringstream input(line);
        double t, x;
        std::string extra;
        if (!(input >> t >> x) || input >> extra || !std::isfinite(t) || !std::isfinite(x))
            throw std::runtime_error("Ошибка данных в строке " + std::to_string(row));
        if (row == 1) s.start = t;
        if (row == 2) s.dt = t - s.start;
        if (row >= 2 && (s.dt <= 0 || std::abs(t - s.start - (row-1)*s.dt) > s.dt*1e-5))
            throw std::runtime_error("Нарушен шаг времени в строке " + std::to_string(row));
        s.x.push_back(x);
    }
    if (s.x.size() < 2) throw std::runtime_error("Требуется хотя бы два отсчёта");
    return s;
}
