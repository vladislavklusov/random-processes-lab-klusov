#include "spectrum.h"
#include <algorithm>
#include <numeric>

Spectrum spectrum(const Series& s) {
    int n = s.x.size();
    int length = 1;
    while (length < 2*n) length *= 2;
    Spectrum result{};
    result.coefficients.resize(length);
    double mean = std::accumulate(s.x.begin(), s.x.end(), 0.0) / n;
    for (int j = 0; j < n; ++j) result.coefficients[j] = s.x[j] - mean;
    fft(result.coefficients, false);
    result.df = 1.0 / (length * s.dt);
    for (int k = 0; k <= length/2; ++k) {
        double factor = (k == 0 || k == length/2) ? 1.0 : 2.0;
        result.amplitude.push_back(factor * std::abs(result.coefficients[k]) / n);
    }
    result.peak = std::max_element(result.amplitude.begin()+1, result.amplitude.end())
                - result.amplitude.begin();
    return result;
}
