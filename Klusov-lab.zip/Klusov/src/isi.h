#pragma once
#include "series.h"
struct ISI {
    int spikes;
    std::vector<double> intervals;
    double mean, variance, sigma, cv;
};
ISI spike_intervals(const Series& s);
