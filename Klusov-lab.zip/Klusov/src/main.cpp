#include "acf.h"
#include "correlation_time.h"
#include "isi.h"
#include "spectrum.h"
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Использование: ./analyze data/*.dat\n";
        return 1;
    }
    std::filesystem::create_directories("results");
    std::ofstream table("results/summary.csv");
    if (!table) return 1;
    table << "file,n,dt,amplitude,frequency,tau,spikes,isi_count,mean_isi,var_isi,sigma_isi,cv,status\n";
    table << std::setprecision(11);
    int errors = 0;
    for (int i = 1; i < argc; ++i) {
        std::string name = std::filesystem::path(argv[i]).filename().string();
        try {
            Series s = read_series(argv[i]);
            Spectrum spec = spectrum(s);
            auto acf = autocorrelation(spec.coefficients, s.x.size());
            bool constant = std::all_of(s.x.begin(), s.x.end(), [&](double x){return x == s.x[0];});
            if (constant) acf.clear();
            double tau = correlation_time(acf, s.dt);
            ISI isi = spike_intervals(s);
            std::string status = "ok";
            if (constant) status = "constant signal";
            else if (!std::isfinite(tau)) status = "no correlation time";
            if (isi.intervals.size() < 2) {
                if (status == "ok") status = "too few ISIs";
                else status += " / too few ISIs";
            }
            table << name << ',' << s.x.size() << ',' << s.dt << ','
                  << (constant ? 0 : spec.amplitude[spec.peak]) << ','
                  << (constant ? NAN : spec.peak*spec.df) << ',' << tau << ','
                  << isi.spikes << ',' << isi.intervals.size() << ',' << isi.mean << ','
                  << isi.variance << ',' << isi.sigma << ',' << isi.cv << ',' << status << '\n';
            if (name == "TSi0a1-05.dat" || argc == 2) {
                std::string prefix = "results/" + std::filesystem::path(name).stem().string();
                std::ofstream sp(prefix + "_spectrum.csv"), ac(prefix + "_acf.csv"), is(prefix + "_isi.csv");
                if (!sp || !ac || !is) throw std::runtime_error("Ошибка записи подробных таблиц");
                sp << std::setprecision(11) << "frequency,amplitude\n";
                ac << std::setprecision(11) << "lag,acf\n";
                is << std::setprecision(11) << "index,isi\n";
                for (size_t k = 0; k < spec.amplitude.size(); ++k)
                    sp << k*spec.df << ',' << spec.amplitude[k] << '\n';
                for (size_t k = 0; k < acf.size(); ++k) ac << k*s.dt << ',' << acf[k] << '\n';
                for (size_t k = 0; k < isi.intervals.size(); ++k) is << k+1 << ',' << isi.intervals[k] << '\n';
            }
            std::cout << name << "  " << status << '\n';
        } catch (const std::exception& e) {
            table << name << ",,,,,,,,,,,," << e.what() << '\n';
            std::cerr << name << ": " << e.what() << '\n';
            ++errors;
        }
    }
    return errors ? 1 : 0;
}
