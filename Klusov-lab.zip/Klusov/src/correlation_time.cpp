#include "correlation_time.h"
#include <cmath>

double correlation_time(const std::vector<double>& acf, double dt) {
    const double level = std::exp(-1.0);
    for (size_t k = 1; k < acf.size(); ++k) {
        if (acf[k] <= level) {
            double fraction = (acf[k-1] - level) / (acf[k-1] - acf[k]);
            return (k-1 + fraction) * dt;
        }
    }
    return NAN;
}
