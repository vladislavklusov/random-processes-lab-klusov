#pragma once
#include "fft.h"
#include "series.h"
struct Spectrum {
    std::vector<Complex> coefficients;
    std::vector<double> amplitude;
    double df;
    int peak;
};
Spectrum spectrum(const Series& s);
