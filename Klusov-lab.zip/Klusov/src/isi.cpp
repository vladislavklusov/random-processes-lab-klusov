#include "isi.h"
#include <cmath>
#include <numeric>

ISI spike_intervals(const Series& s) {
    ISI result{0, {}, NAN, NAN, NAN, NAN};
    double previous = 0;
    for (size_t j = 1; j < s.x.size(); ++j) {
        double left = s.x[j-1], right = s.x[j];
        if (left <= 0 && right > 0) {
            double fraction = -left / (right-left);
            double time = s.start + (j-1 + fraction)*s.dt;
            if (result.spikes > 0) result.intervals.push_back(time-previous);
            previous = time;
            ++result.spikes;
        }
    }
    const auto& intervals = result.intervals;
    if (intervals.empty()) return result;
    result.mean = std::accumulate(intervals.begin(), intervals.end(), 0.0) / intervals.size();
    if (intervals.size() < 2) return result;
    double sum = 0;
    for (double isi : intervals) sum += (isi-result.mean)*(isi-result.mean);
    result.variance = sum / intervals.size();
    result.sigma = std::sqrt(result.variance);
    result.cv = result.sigma / result.mean;
    return result;
}
