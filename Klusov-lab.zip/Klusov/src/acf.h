#pragma once
#include "fft.h"
std::vector<double> autocorrelation(std::vector<Complex> coefficients, int n);
