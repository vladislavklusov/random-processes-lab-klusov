#pragma once
#include <string>
#include <vector>

struct Series {
    std::vector<double> x;
    double start;
    double dt;
};
Series read_series(const std::string& path);
