#include "acf.h"
#include <cmath>

std::vector<double> autocorrelation(std::vector<Complex> coefficients, int n) {
    for (auto& z : coefficients) z = std::norm(z);
    fft(coefficients, true);
    std::vector<double> acf;
    double energy = coefficients[0].real();
    if (energy <= 0) return acf;
    for (int k = 0; k < n; ++k) acf.push_back(coefficients[k].real()/energy);
    return acf;
}
