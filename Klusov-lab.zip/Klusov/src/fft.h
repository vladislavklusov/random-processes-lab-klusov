#pragma once
#include <complex>
#include <vector>
using Complex = std::complex<double>;
void fft(std::vector<Complex>& a, bool inverse);
