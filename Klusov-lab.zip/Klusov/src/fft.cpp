#include "fft.h"
#include <cmath>

void fft(std::vector<Complex>& a, bool inverse) {
    const int n = a.size();
    if (n == 1) return;
    std::vector<Complex> even(n/2), odd(n/2);
    for (int j = 0; j < n/2; ++j) {
        even[j] = a[2*j];
        odd[j] = a[2*j+1];
    }
    fft(even, inverse);
    fft(odd, inverse);
    double angle = (inverse ? 2 : -2) * std::acos(-1.0) / n;
    Complex step = std::polar(1.0, angle);
    Complex w = 1;
    for (int j = 0; j < n/2; ++j) {
        Complex term = w * odd[j];
        a[j] = even[j] + term;
        a[j+n/2] = even[j] - term;
        if (inverse) {
            a[j] /= 2;
            a[j+n/2] /= 2;
        }
        w *= step;
    }
}
