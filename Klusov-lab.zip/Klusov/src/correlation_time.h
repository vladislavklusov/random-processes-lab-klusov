#pragma once
#include <vector>
double correlation_time(const std::vector<double>& acf, double dt);
