import math
import random
from concurrent.futures import ProcessPoolExecutor


def characteristics(mean, m2, m3, m4):
    if m2 == 0:
        return mean, 0.0, math.nan, math.nan
    return mean, m2, m3 / m2**1.5, m4 / m2**2 - 3


def centered_sums(values, mean):
    s2 = s3 = s4 = 0.0
    for x in values:
        d = x - mean
        s2 += d**2
        s3 += d**3
        s4 += d**4
    return s2, s3, s4


def naive(values):
    n = len(values)
    mean = sum(values) / n
    s2, s3, s4 = centered_sums(values, mean)
    return characteristics(mean, s2/n, s3/n, s4/n)


def parallel(values):
    n = len(values)
    middle = n // 2
    parts = [values[:middle], values[middle:]]
    with ProcessPoolExecutor(max_workers=2) as pool:
        mean = sum(pool.map(sum, parts)) / n
        sums = list(pool.map(centered_sums, parts, [mean, mean]))
    s2, s3, s4 = (sum(column) for column in zip(*sums))
    return characteristics(mean, s2/n, s3/n, s4/n)


def online(stream):
    it = iter(stream)
    origin = next(it)
    n = 1
    s1 = s2 = s3 = s4 = 0.0
    for x in it:
        y = x - origin
        n += 1
        s1 += y
        s2 += y**2
        s3 += y**3
        s4 += y**4
    a, b, c, d = s1/n, s2/n, s3/n, s4/n
    m2 = b - a*a
    m3 = c - 3*a*b + 2*a**3
    m4 = d - 4*a*c + 6*a*a*b - 3*a**4
    return characteristics(origin + a, m2, m3, m4)


def main():
    rng = random.Random(42)
    n = 50000
    processes = {
        "Нормальный белый шум": [rng.gauss(0, 1) for _ in range(n)],
        "Независимые экспоненциальные отсчёты": [rng.expovariate(1) for _ in range(n)]
    }
    for name, values in processes.items():
        print(name)
        print("Метод           Среднее   Дисперсия  Асимметрия     Эксцесс")
        reference = naive(values)
        for method in (naive, parallel, online):
            result = reference if method is naive else method(values)
            print(f"{method.__name__:10}", *(f"{v:11.6f}" for v in result))
            assert all(math.isclose(a, b, abs_tol=1e-8) for a, b in zip(reference, result))
        print()


if __name__ == "__main__":
    main()
